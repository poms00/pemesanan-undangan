import 'package:flutter/material.dart';
import 'detail.dart';

class FormProdukPage extends StatefulWidget {
  const FormProdukPage({super.key});

  @override
  State<FormProdukPage> createState() => _FormProdukPageState();
}

class _FormProdukPageState extends State<FormProdukPage> {
  final TextEditingController barcodeController = TextEditingController();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController hargaController = TextEditingController();
  final TextEditingController stokController = TextEditingController();
  final TextEditingController pabrikanController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Form Produk"),
        backgroundColor: Colors.lightBlue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildTextField("No Barcode Produk", barcodeController),
            _buildTextField("Nama Produk", namaController),
            _buildTextField(
              "Harga Produk",
              hargaController,
              keyboardType: TextInputType.number,
            ),
            _buildTextField(
              "Stok Produk",
              stokController,
              keyboardType: TextInputType.number,
            ),
            _buildTextField("Pabrikan", pabrikanController),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) => DetailProdukPage(
                          barcode: barcodeController.text,
                          nama: namaController.text,
                          harga: hargaController.text,
                          stok: stokController.text,
                          pabrikan: pabrikanController.text,
                        ),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
              ),
              child: const Text("Simpan"),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
    String label,
    TextEditingController controller, {
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
      ),
    );
  }
}
