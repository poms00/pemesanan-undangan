import 'package:flutter/material.dart';

class DetailProdukPage extends StatelessWidget {
  final String barcode;
  final String nama;
  final String harga;
  final String stok;
  final String pabrikan;

  const DetailProdukPage({
    super.key,
    required this.barcode,
    required this.nama,
    required this.harga,
    required this.stok,
    required this.pabrikan,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Detail Produk"),
        backgroundColor: Colors.lightBlue,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildDetailText("No Barcode Produk = $barcode"),
            _buildDetailText("Nama Produk = $nama"),
            _buildDetailText(
              "Harga Produk = Rp ${int.parse(harga).toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (m) => '${m[1]}.')}",
            ),
            _buildDetailText("Stok Produk = $stok Biji"),
            _buildDetailText("Pabrikan = $pabrikan"),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24,
                    vertical: 12,
                  ),
                ),
                child: const Text("Kembali"),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailText(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Text(text, style: const TextStyle(fontSize: 16)),
    );
  }
}
